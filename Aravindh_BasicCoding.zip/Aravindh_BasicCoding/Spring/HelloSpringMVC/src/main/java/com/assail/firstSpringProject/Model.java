package com.assail.firstSpringProject;

public class Model {

}
